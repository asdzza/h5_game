《撞个正着》v1.0
================

运行方式（推荐）：
1. 解压压缩包，保持 index.html、styles.css、src/ 在同一目录。
2. 在该目录启动任意静态服务器，例如：
      python -m http.server 8080
   然后浏览器打开 http://localhost:8080/
3. 也可以把解压后的全部文件上传到任意静态托管（GitHub Pages、Nginx、对象存储等），
   保证 index.html 位于站点根目录即可。

为什么不能直接双击 index.html
本作使用原生 ES Module 加载脚本，Chrome / Edge / Safari 在 file:// 协议下会
对模块脚本做安全限制，直接双击会提示 CORS 错误、无法启动游戏。通过
http://localhost 或任意 HTTP(S) 静态服务器打开即可。

说明
- 无第三方依赖，不需要安装、不需要构建。
- 进度保存在浏览器 localStorage（键名 zgz.save.v2）。
- 支持触屏、鼠标、键盘；推荐使用最新版 Chrome / Edge / Safari。
- 固定 50 关，无额外模式、每日挑战或内购。
- 默认 50 关全部可选；想体验逐关解锁，在地址后加 ?locked=1。
- 首次遇到钉子 / 泊位 / 最后一对时，游戏内会弹一张新规则卡；右上角「?」可看全部规则。

在线试玩：https://asdzza.github.io/h5_game/